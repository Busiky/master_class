d = {}


def fact(n):
    if n in d:
        return d[n]
    if not n:
        d[n] = 1
    else:
        d[n] = fact(n - 1) * n
    return d[n]


print(fact(100))
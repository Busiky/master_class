import itertools

board = itertools.product('ABCDEFGH', '12345678')
d = dict.fromkeys(board)
for _ in range(13):
    d[tuple(input())] = 'p'
print(d)
'''
A7
B3
B4
D4
D5
E3
E6
F4
F7
G4
G6
H3
H5
'''
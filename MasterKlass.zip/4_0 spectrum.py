import collections

d = collections.defaultdict(list)

with open('spectrum.txt', 'r') as file:
    data = file.read().split()

for i in range(0, len(data) - 1, 2):
    length = float(data[i].replace(',', '.'))
    elem = data[i + 1]
    d[elem].append(length)
# print(dict(d))

line = list(map(float, input().split(', ')))

answer = collections.defaultdict(list)
# находим название элемента для данной линии и добавляем в словарь answer
# элемент - список линий
for key, value in d.items():
    for length in line:
        if length in value:
            answer[key].append(length)
# теперь надо сравнить списки значений для данного элемента
# поскольку порядок не важен, сравниваем множества
for key in answer.keys():
    if set(answer[key]) == set(d[key]):
        print(key)

# 228.81, 234.98, 278.02, 286.05, 252.85, 259.81, 287.79, 249.68, 249.77, 247.86

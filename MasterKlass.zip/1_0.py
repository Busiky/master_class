line = input().split()
d = {}
for word in line:
    if word not in d:
        d[word] = 1
    else:
        d[word] += 1
    print(d[word], end=' ')

'''Раз раз два три повторяю раз два три раз'''

rna = input()
d = dict()
for i in range(4, len(rna)):
    tetra = rna[i - 4:i]
    d[tetra] = d.get(tetra, 0) + 1
print(d)

# по ключам по алфавиту
d_sorted_0 = sorted(d.items())
print(d_sorted_0)

# по значениям по возрастанию
d_sorted_1 = sorted(d.items(), key=lambda x: x[1])
print(d_sorted_1)

# по убыванию
d_sorted_2 = sorted(d.items(), key=lambda x: -x[1])
print(d_sorted_2)

'''АГАГАГУУЦААЦУУГГЦАЦГУГЦАЦААГАГАГАГУУЦААЦУУГГЦАЦГУГЦАЦААГ'''

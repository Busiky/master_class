d = {}
line = input()
while line:
    line = line.split(' - ')
    if line[0] not in d:
        d[line[0]] = [line[1]]
    else:
        d[line[0]].append(line[1])
    line = input()

example = input()
for key, value in d.items():
    if example in value:
        print(key)
        break

keys = ['фамилия', 'имя', 'класс', 'буква класса', 'увлечения']
data = []
with open('6_0.txt', 'r') as file:
    lines = file.readlines()

for line in lines:
    d = dict.fromkeys(keys)
    surname, name, class_, letter, *hobbies = line.split()
    d['фамилия'] = surname
    d['имя'] = name
    d['класс'] = int(class_)
    d['буква класса'] = letter
    d['увлечения'] = hobbies
    data.append(d)
print(*data, sep='\n')

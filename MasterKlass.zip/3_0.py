with open('cities_coords.txt', 'r') as file:
    data = file.readlines()

coordinates = {}
cities = {}

for line in data:
    city, coords = line.rstrip().split('\t')
    coords = tuple(map(float, coords.split(', ')))
    coordinates[coords] = city
    cities[city] = coords

city_to_find = input()
coords_to_find = tuple(map(float, input().split(', ')))
print(f'Координаты города {city_to_find}: {cities[city_to_find]}')
print(f'По координатам {coords_to_find} находится город {coordinates[coords_to_find]}')
'''Пенза
55.15, 37.48'''

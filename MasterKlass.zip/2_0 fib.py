d = {}


def fib(n):
    if n in d:
        return d[n]
    if n < 3:
        d[n] = 1
    else:
        d[n] = fib(n - 1) + fib(n - 2)
    return d[n]


print(fib(60))

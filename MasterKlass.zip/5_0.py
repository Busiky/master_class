d = dict()

line = input()
while line:
    line = line.split(' - ')
    d[line[0]] = [tuple(x.split(', ')) for x in line[1].split('; ')]
    line = input()

word, language = input().split()
for translation in d[word]:
    if translation[0] == language[1:-1]:
        print(translation[1])
